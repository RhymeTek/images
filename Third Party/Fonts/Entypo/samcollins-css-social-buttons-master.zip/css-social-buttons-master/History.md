
1.0.0 / 2015-04-11
==================

First versioned release !

Recently added fontcustom support.

