
airports
	geoNameId: 	geoNameId of airport
	name: 		main name of airport (refer to alternate names for translations)
	featureCode: 	the featurecode (AIRB,AIRF,AIRH,AIRP,AIRQ)
	countryCode: 	the iso country code
	adminCode1: 	the geoNames adm1 code
	adminCode2:	the geoNames adm2 code
	timeZoneId:	the olson timezoneId
	latitude:	latitude
	longitude:	longitude
	iata:		the 3 char iata airport code (if available)
	icao:		the 4 char icao airport code (if available)
	cityId:		the geoNameId of the city served
	cityName:	the main name of the city served
	isActive:	flag to indicate wether the airport is active (1=true)


boundingbox.zip
	geoNameId: 	geoNameId of feature
	bBoxWest:	most western longitude
	bBoxSouth:	most southern latitude
	bBoxEast:	most eastern longitude
	bBoxNorth:	most northern latitude
	

countrysubdivision.txt
	countryCode:	ISO two letter country code
	name:		name of admin division
	geonameId:	geonameid of corresponding geoname
	geoNamesLevel:	level of corresponding geonames admin division
	geoNamesAdmCode geonames adm code
	ISO_3166_2:	ISO 3166-2 code
	fips:		US code (formerly FIPS PUB 10-4)
	languages:	ISO language codes, comma separated



depencencies.txt
	iso code:	iso country code of depencencies, empty if no iso code exists
	fips code:	fips country code, empty if no fips code exists
	name:		name of dependency
	depends from:	comma separated list of countries it depends from (iso codes)
	featurecode:	the feature code in geoNames
	geonameid:	the corresponding geoNameId
	claimed by:	disputed area, also claimed by other countries
	continent:	the continent the depency belongs to geographically



spot_city.zip
	spotid:		geoNameId of spot feature
	cityid:		geoNameId of city the spot belongs to
	city15000id:	geoNameId of city from cities15000 file the spot belongs to
	city5000id:	geoNameId of city from cities5000 file the spot belongs to
	city1000id:	geoNameId of city from cities5000 file the spot belongs to



unlocode-geonameid.zip
	countryCode: 	ISO country code
	Un Locode:	The UN Locode
	Name: 		The name of the feature according to the UN Locode dataset
	geoNameId:	The geoNameId of the corresponding geonames feature
