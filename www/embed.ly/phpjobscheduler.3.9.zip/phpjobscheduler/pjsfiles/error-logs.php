<?php
$app_name = "phpJobScheduler";
$phpJobScheduler_version = "3.9";
// -------------------------------
include_once("functions.php");

include("header.html");
include("error-logs.html");
include("footer.html");
?>